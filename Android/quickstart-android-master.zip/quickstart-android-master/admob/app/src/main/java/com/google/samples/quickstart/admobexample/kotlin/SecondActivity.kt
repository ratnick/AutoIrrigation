package com.google.samples.quickstart.admobexample.kotlin

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.google.samples.quickstart.admobexample.R

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)
    }
}
